create definer = root@localhost view creditdata as
select `i`.`name`       AS `InstitutionName`,
       `c`.`name`       AS `CategoryName`,
       `ia`.`name`      AS `Impact_AreaName`,
       `ct`.`name`      AS `CreditName`,
       `ct`.`indicator` AS `indicator`,
       `ct`.`point`     AS `point`
from (((`sustainability_data`.`institution` `i` join `sustainability_data`.`category` `c`
        on ((`i`.`id` = `c`.`institution_id`))) join `sustainability_data`.`impact_area` `ia`
       on ((`c`.`id` = `ia`.`category_id`))) join `sustainability_data`.`credit` `ct`
      on ((`ia`.`id` = `ct`.`impact_area_id`)));

