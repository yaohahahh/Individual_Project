create definer = root@localhost trigger after_insert_insitution
    after insert
    on Institution
    for each row
begin
    DECLARE id INT;
SET id=NEW.id;
INSERT INTO Category (name, institution_id,type) VALUES ('Academics',id,'Society'), ('Engagement',id,'Society'),('Operations',id,'Environment'), ('Planning & Administration',id,'Economy'),('Innovation & Leadership',id,'Economy');
end;

