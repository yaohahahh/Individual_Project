create definer = root@localhost trigger update_impact_area_points
    after update
    on Credit
    for each row
BEGIN
    DECLARE total_points INT;
    SELECT SUM(points) INTO total_points
    FROM Credits
    WHERE impact_area_id = NEW.impact_area_id;
    
    UPDATE ImpactAreas
    SET points = total_points
    WHERE id = NEW.impact_area_id;
END;

