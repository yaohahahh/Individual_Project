create definer = root@localhost trigger after_insert_category
    after insert
    on Category
    for each row
begin
    DECLARE id INT;
set id =NEW.id;

IF NEW.name = 'Academics' THEN
INSERT INTO Impact_Area(name,category_id,total_point) VALUES ('Curriculum',id,40),('Research',id,18);

ELSEIF NEW.name = 'Engagement' THEN
INSERT INTO Impact_Area(name,category_id,total_point) VALUES ('Campus Engagement',id,21),('Public Engagement',id,20);

ELSEIF NEW.name = 'Operations' THEN
INSERT INTO Impact_Area(name,category_id,total_point) VALUES ('Buildings & Grounds',id,20),
    ('Energy & Climate',id,21),('Food & Dining',id,8),('Procurement & Waste',id,16),('Transportation',id,7);
    
ELSEIF NEW.name = 'Planning & Administration' THEN
INSERT INTO Impact_Area(name,category_id,total_point) VALUES ('Coordination & Planning',id,9),
    ('Investment',id,8),('Social Equity',id,10),('Wellbeing & Work',id,7);
    
ELSEIF NEW.name = 'Innovation & Leadership' THEN
    INSERT INTO Impact_Area(name,category_id,total_point) VALUES ('Innovation & Leadership',id,4);

END IF;

end;

