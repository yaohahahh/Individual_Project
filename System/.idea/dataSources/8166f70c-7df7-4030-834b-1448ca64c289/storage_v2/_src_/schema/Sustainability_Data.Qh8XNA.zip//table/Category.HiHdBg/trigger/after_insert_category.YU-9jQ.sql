create definer = root@localhost trigger after_insert_category
    after insert
    on Category
    for each row
begin
    DECLARE id INT;
set id =NEW.id;

IF NEW.name = 'Academics' THEN
INSERT INTO Impact_Area(name,category_id) VALUES ('Curriculum',id),
                                                 ('Research',id);
ELSEIF NEW.name = 'Engagement' THEN
INSERT INTO Impact_Area(name,category_id) VALUES ('Campus Engagement',id),
                                                     ('Public Engagement',id);
ELSEIF NEW.name = 'Operations' THEN
INSERT INTO Impact_Area(name,category_id) VALUES ('Buildings & Grounds',id),
    ('Energy & Climate',id),('Food & Dining',id),('Procurement & Waste',id),('Transportation',id);
ELSEIF NEW.name = 'Planning & Administration' THEN
INSERT INTO Impact_Area(name,category_id) VALUES ('Coordination & Planning',id),
    ('Investment',id),('Social Equity',id),('Wellbeing & Work',id);
ELSEIF NEW.name = 'Innovation & Leadership' THEN
    INSERT INTO Impact_Area(name,category_id) VALUES ('Innovation & Leadership',id);

END IF;

end;

